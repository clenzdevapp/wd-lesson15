# About

Basic boilerplate code for Google App Engine projects.

### Instructions

1. Click on Download ZIP
2. Save on your disk and unzip
3. Run the code with this command: `dev_appserver.py ./`
4. Open your browser and go to: `http://localhost:8080/`
